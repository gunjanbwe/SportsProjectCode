package com.android.sportsapp.UI.TeamsScreen

import androidx.lifecycle.ViewModel

class TeamScreenViewModel : ViewModel() {
//Not Used
}