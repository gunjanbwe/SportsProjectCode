package com.android.sportsapp.UI.SportScreen

import android.content.Context
import android.widget.Toast
import androidx.lifecycle.MutableLiveData
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.google.gson.Gson
import com.android.sportsapp.DataModels.SportDetail
import com.android.sportsapp.Network.SportService
import kotlinx.coroutines.GlobalScope
import kotlinx.coroutines.launch
import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.Response

class SportsViewModel : ViewModel() {

    val listOfMatch=MutableLiveData<ArrayList<SportDetail>>()

    fun useCoroutinecricketData(getCricketApi:SportService, mContext:Context){

        // launching a new coroutine
        viewModelScope.launch {
            val result = getCricketApi.getCricketData()
            result.enqueue(object :retrofit2.Callback<ResponseBody> {
                override fun onResponse(
                    call: Call<ResponseBody>,
                    response: Response<ResponseBody>
                ) {
                    if (response.isSuccessful) {
                        val responseBody = response.body()
                        val jsonString = responseBody?.string()
                        //  val jsonObject = JSONObject(jsonString) not using object for now

                        val gson = Gson()
                        val matchDetail = gson.fromJson(jsonString, SportDetail::class.java)
                        val currentMatchs=ArrayList<SportDetail>()
                        currentMatchs.add(matchDetail)
                        listOfMatch.postValue(currentMatchs)
                       // Log.d("TAG", "onResponse: "+matchDetail.toString())

                    } else {
                        // API error
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(mContext, "Something went wrong...", Toast.LENGTH_SHORT).show()
                    t.printStackTrace()
                }

            })

        }

    }
    fun useCoroutineCricketDetails(getMatchApi:SportService, mContext:Context){

        // launching a new coroutine
        GlobalScope.launch {
            val result = getMatchApi.getCricketDetails()
            result.enqueue(object :retrofit2.Callback<ResponseBody> {
                override fun onResponse(
                    call: Call<ResponseBody>,
                    response: Response<ResponseBody>
                ) {
                    if (response.isSuccessful) {
                        val responseBody = response.body()
                        val jsonString = responseBody?.string()
                        //  val jsonObject = JSONObject(jsonString) not using object for now

                        val gson = Gson()
                        val matchDetail = gson.fromJson(jsonString, SportDetail::class.java)
                        val currentMatchs=ArrayList<SportDetail>()
                        currentMatchs.add(matchDetail)
                        listOfMatch.postValue(currentMatchs)


                    } else {
                        // API error
                    }
                }

                override fun onFailure(call: Call<ResponseBody>, t: Throwable) {
                    Toast.makeText(mContext, "Something went wrong...", Toast.LENGTH_SHORT).show()
                   t.printStackTrace()
                }

            })

        }

    }



  /*  fun loadDataFromAssets(mContext:Context){
        lateinit var jsonString: String
        try {
            jsonString = mContext.assets.open("data/dummyData.json")
                .bufferedReader()
                .use { it.readText() }
        } catch (ioException: IOException) {
           ioException.printStackTrace()
        }
        val gson = Gson()
        val matchDetail = gson.fromJson(jsonString, MatchDetail::class.java)
        val currentMatchs=ArrayList<MatchDetail>()
        currentMatchs.add(matchDetail)
        listOfMatch.postValue(currentMatchs)
    }*/
}