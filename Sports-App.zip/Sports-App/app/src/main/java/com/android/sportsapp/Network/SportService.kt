package com.android.sportsapp.Network

import okhttp3.ResponseBody
import retrofit2.Call
import retrofit2.http.GET

interface SportService {
    @GET("/nzin01312019187360.json")
     fun getCricketData() : Call<ResponseBody>

    @GET("/sapk01222019186652.json")
    fun getCricketDetails() : Call<ResponseBody>
}