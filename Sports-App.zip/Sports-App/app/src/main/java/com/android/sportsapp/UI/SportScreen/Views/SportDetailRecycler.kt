package com.android.sportsapp.UI.SportScreen.Views

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View

import android.view.ViewGroup
import androidx.navigation.findNavController
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.android.sportsapp.DataModels.SportDetail
import com.android.sportsapp.R
import com.android.sportsapp.databinding.MatchDetailItemBinding

class SportDetailRecycler(private val data: ArrayList<SportDetail>)  : RecyclerView.Adapter<SportDetailRecycler.ViewHolder>() {

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        val binding = MatchDetailItemBinding.inflate(inflater, parent, false)
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = data[position]
        holder.bind(item)
    }

    override fun getItemCount(): Int {
        return data.size
    }


    inner class ViewHolder(private val binding: MatchDetailItemBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(item: SportDetail) {
            binding.textTeamHome.text = item.teams[item.match.teamHome]?.name_full ?: "null"
            binding.textTeamAway.text = item.teams[item.match.teamAway]?.name_full ?: "null"
            binding.textVenue.text=item.match.venue.name
            binding.textDate.text=item.match.match.date
            binding.textSeriesDetails.text=item.match.series.name
            binding.textReferee.text=item.match.officials.referee
            binding.textUmpires.text=item.match.officials.umpires
            binding.textMatchStatus.text=item.match.status
            binding.textMatchResult.text=item.match.result
            val bundle=Bundle()
            val gson=Gson()
            bundle.putString("data",gson.toJson(item))
            binding.navigateButtonDetails.setOnClickListener(View.OnClickListener {
                it.findNavController().navigate(R.id.team_screen,bundle)
            })
        }
    }
}