package com.android.sportsapp.UI.TeamsScreen

import androidx.lifecycle.ViewModelProvider
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.AdapterView
import android.widget.ArrayAdapter
import android.widget.Spinner
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.gson.Gson
import com.android.sportsapp.DataModels.SportDetail
import com.android.sportsapp.DataModels.Player
import com.android.sportsapp.UI.TeamsScreen.Views.PlayerAdapter
import com.android.sportsapp.databinding.FragmentTeamScreenBinding

class TeamScreen : Fragment() {

    companion object {
        fun newInstance() = TeamScreen()
    }

    private var _binding: FragmentTeamScreenBinding? = null
    private val binding get() = _binding!!
    private lateinit var viewModel: TeamScreenViewModel




    var dataList=ArrayList<Player>()
    private lateinit var teamRecyclerView: RecyclerView
    private lateinit var adapter: PlayerAdapter

    private lateinit var mode_Spinner: Spinner
    var mode_selection= arrayOf("Team A","Team B","All")
    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        _binding = FragmentTeamScreenBinding.inflate(inflater, container, false)
        val view = binding.root
        viewModel = ViewModelProvider(this)[TeamScreenViewModel::class.java]


        //parsing args
        val args=arguments
        val data= args?.getString("data")
        val gson = Gson()
        val matchDetail = gson.fromJson(data, SportDetail::class.java)


        //recyclerView
        adapter= PlayerAdapter(dataList)
        teamRecyclerView=binding.teamRecyclerView
        mode_Spinner=binding.mySpinner
        teamRecyclerView.adapter = adapter
        teamRecyclerView.layoutManager = LinearLayoutManager(context)

        //spinner
        val selection_adapter = context?.let { ArrayAdapter(it, android.R.layout.simple_spinner_item, mode_selection) }
        selection_adapter?.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item)

        mode_Spinner.adapter=selection_adapter


        //selection logic
        mode_Spinner.onItemSelectedListener = object :
            AdapterView.OnItemSelectedListener {
            override fun onItemSelected(parent: AdapterView<*>, view: View, position: Int, id: Long) {
                teams_selection(matchDetail,mode_selection[position])
            }

            override fun onNothingSelected(parent: AdapterView<*>) {

            }
        }


        return view


    }

    fun teams_selection(matchDetail: SportDetail,selection: String){
        if(dataList.size>0){
            dataList.clear()
        }
        if(selection == "Team A" || selection=="All"){
            matchDetail.teams[matchDetail.match.teamHome]?.players?.forEach { (s, player) ->
                player.team_name=matchDetail.teams[matchDetail.match.teamHome]?.name_full ?: "null"
                dataList.add(player)
            }
            adapter.notifyDataSetChanged()
        }
        if(selection == "Team B"|| selection=="All"){
            matchDetail.teams[matchDetail.match.teamAway]?.players?.forEach { (s, player) ->
                player.team_name=matchDetail.teams[matchDetail.match.teamAway]?.name_full ?: "null"
                dataList.add(player)
            }
            adapter.notifyDataSetChanged()
        }

    }
    override fun onDestroyView() {
        super.onDestroyView()
        _binding=null
    }


}